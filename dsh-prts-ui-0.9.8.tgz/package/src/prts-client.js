/**
 * dsh-prts-ui/client — the PRTS client plugin.
 *
 * PRTS runs AS a dsh-web client plugin in the isolated `prts` profile: the
 * shell is dsh-web itself, so the settings pages are the official ones
 * (identical to web), every plugin the market installs shows its own
 * buttons/panels exactly where dsh-web puts them, and performance is
 * dsh-web's own. The official `dsh web` profile never loads this plugin, so
 * `dsh web` stays the original DeepSeek Harness UI. PRTS contributes:
 *   - the PRTS skin (monochrome tokens + custom accent/wallpaper/glass),
 *   - the particle intro (welcome to PRTS → PRTS/DeepSeek Harness banner →
 *     the PRTS diamond mark),
 *   - sidebar actions (Git / SKILL市场 / 系统),
 *   - a "PRTS" settings section (balance, git, SKILL市场, wallpaper, colors,
 *     sidebar buttons),
 *   - the first-run API-key onboarding (any port).
 *
 * Plain JavaScript: React.createElement only, no JSX/TS transform.
 */

import React from 'react'
import { createRoot } from 'react-dom/client'

const SILL = '__SKILL_CATALOG__'

/** Services this plugin waits for before applying: the slot registry (client
 *  runtime) and the theme registry (client theme). Both are provided by the
 *  stock dsh web boot, so the skin always lands on a ready shell. */
export const inject = ['slots', 'theme']

export function apply(ctx) {
  const slots = ctx.get('slots')
  const theme = ctx.get('theme')

  const R = React
  const { useState, useEffect, useRef, useCallback } = React

  const origin = () => (typeof window !== 'undefined' ? window.location.origin : '')
  const api = async (method, path, body) => {
    const res = await fetch(origin() + path, {
      method: method || 'GET',
      headers: { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
    })
    if (!res.ok) throw new Error('HTTP ' + res.status)
    return res.json()
  }
  const getConfig = () => api('GET', '/prts/api/config').catch(() => ({}))
  const setConfig = (patch) => api('POST', '/prts/api/config', patch).catch(() => ({ ok: false }))

  /* ---------- PRTS skin ---------- */
  // overrideTokens() takes token -> { light, dark } pairs (one value per
  // color scheme) — the inverted shape silently no-ops at runtime.
  const PRTS_TOKENS = {
    '--dsw-alias-bg-base': { dark: '#0A0A0B', light: '#FAFAFA' },
    '--dsw-alias-bg-layer-1': { dark: '#111112', light: '#F3F3F3' },
    '--dsw-alias-bg-layer-2': { dark: '#161618', light: '#EBEBEB' },
    '--dsw-alias-bg-overlay': { dark: '#0D0D0E', light: '#FFFFFF' },
    '--dsw-alias-border-l1': { dark: 'rgba(250,250,250,0.14)', light: 'rgba(10,10,11,0.14)' },
    '--dsw-alias-border-l2': { dark: 'rgba(250,250,250,0.3)', light: 'rgba(10,10,11,0.3)' },
    '--dsw-alias-brand-primary': { dark: '#FAFAFA', light: '#0A0A0B' },
    '--dsw-alias-label-primary': { dark: '#FAFAFA', light: '#0A0A0B' },
    '--dsw-alias-label-secondary': { dark: '#9C9CA1', light: '#5C5C60' },
    '--dsw-alias-state-error-primary': { dark: '#f7768e', light: '#d93025' },
    '--dsw-alias-state-success-primary': { dark: '#9ece6a', light: '#188038' },
    '--dsw-alias-state-warn-primary': { dark: '#e0af68', light: '#b06000' },
    '--dsw-specific-sidebar-fill': { dark: '#0D0D0E', light: '#FFFFFF' },
  }

  let appliedAccent = null
  /** Mix two #rrggbb colors; t = share of b (0..1). */
  function mixHex(a, b, t) {
    try {
      const r = ((parseInt(String(a).slice(1, 3), 16) * (1 - t) + parseInt(String(b).slice(1, 3), 16) * t) | 0)
      const g = ((parseInt(String(a).slice(3, 5), 16) * (1 - t) + parseInt(String(b).slice(3, 5), 16) * t) | 0)
      const bl = ((parseInt(String(a).slice(5, 7), 16) * (1 - t) + parseInt(String(b).slice(5, 7), 16) * t) | 0)
      return '#' + [r, g, bl].map((v) => v.toString(16).padStart(2, '0')).join('')
    } catch (e) { return b }
  }
  async function applySkin(cfg) {
    // monochrome base tokens (light + dark)
    if (theme) { try { theme.overrideTokens('prts', PRTS_TOKENS) } catch (e) { /* token API may reject */ } }
    const ui = (cfg && cfg.ui) || {}
    const root = document.documentElement
    const setVar = (k, v) => {
      if (v) root.style.setProperty(k, v)
      else root.style.removeProperty(k)
    }
    // Fixed monochrome ink for the background marks and the hero mark: they
    // follow only light/dark (and 跟随系统), never a preset.
    let activeId = 'dark'
    try {
      const snap = theme && theme.getTheme ? theme.getTheme() : null
      // snapshot shape: { preference, active: { id, ... }, ... }
      activeId = (snap && snap.active && snap.active.id) || (snap && snap.preference) || (snap && snap.id) || 'dark'
    } catch (e) { /* noop */ }
    setVar('--prts-ink', activeId === 'light' ? '#0A0A0B' : '#FAFAFA')
    document.documentElement.dataset.prtsTheme = activeId
    // Glass blur amount (background blur slider).
    setVar('--prts-blur', (ui.blur !== undefined ? ui.blur : 12) + 'px')
    // Theme = PRESETS ONLY (or '' for the system default). The preset hue
    // colors text/buttons/borders and tints the background when no
    // wallpaper is set; the preset adapts to light/dark automatically.
    const preset = THEME_PRESETS.find(([id]) => id === ui.theme)
    const p = preset ? preset[2] : null
    setVar('--prts-accent', p || '')
    if (p) {
      const darkTint = {
        '--dsw-alias-brand-primary': p,
        '--dsw-alias-border-l2': mixHex('#FAFAFA', p, 0.55),
        '--dsw-alias-label-secondary': mixHex('#9C9CA1', p, 0.3),
        '--dsw-alias-bg-base': mixHex('#0A0A0B', p, 0.08),
        '--dsw-alias-bg-layer-1': mixHex('#111112', p, 0.07),
        '--dsw-alias-bg-overlay': mixHex('#0D0D0E', p, 0.06),
      }
      const lightTint = {
        '--dsw-alias-brand-primary': p,
        '--dsw-alias-border-l2': mixHex('#0A0A0B', p, 0.5),
        '--dsw-alias-label-secondary': mixHex('#5C5C60', p, 0.3),
        '--dsw-alias-bg-base': mixHex('#FAFAFA', p, 0.05),
        '--dsw-alias-bg-layer-1': mixHex('#F3F3F3', p, 0.04),
        '--dsw-alias-bg-overlay': mixHex('#FFFFFF', p, 0.04),
      }
      const toTokenModes = (darkMap, lightMap) => {
        const out = {}
        for (const k of Object.keys(darkMap)) out[k] = { dark: darkMap[k], light: lightMap[k] }
        return out
      }
      if (theme) { try { theme.overrideTokens('prts-accent', toTokenModes(darkTint, lightTint)) } catch (e) { /* noop */ } }
    }
    appliedAccent = !!p
    // glass master switch
    document.body.dataset.glass = ui.glass === false ? 'off' : 'on'
    // drawer motion config
    setVar('--prts-drawer-ms', (ui.drawerMs || 380) + 'ms')
    document.documentElement.dataset.prtsDrawerOff = ui.drawer === false ? '1' : ''
    applyWallpaper(cfg)
  }

  async function applyWallpaper(cfg) {
    const w = cfg && cfg.ui && cfg.ui.wallpaper
    let layer = document.getElementById('prtsWallpaperLayer')
    if (!w || (!w.file && !w.url)) {
      if (layer) layer.remove()
      return
    }
    if (!layer) {
      layer = document.createElement('div')
      layer.id = 'prtsWallpaperLayer'
      layer.setAttribute('aria-hidden', 'true')
      document.body.appendChild(layer)
    }
    layer.style.cssText = 'position:fixed;inset:0;z-index:0;overflow:hidden;pointer-events:none;background:var(--dsw-alias-bg-base);opacity:' + (w.opacity !== undefined ? w.opacity : 1) + ';'
    // fit: 覆盖 cover / 填充 fill / 自由 free (natural size) / 居中 contain
    const fitMap = { cover: 'cover', fill: 'fill', free: 'none', contain: 'contain' }
    try {
      let src = w.url || ''
      if (!src) {
        const data = await api('GET', '/prts/api/wallpaper?file=' + encodeURIComponent(w.file))
        if (!data || !data.dataUrl) return
        src = data.dataUrl
      }
      layer.innerHTML = ''
      let media
      if (w.type === 'video' || /\.(mp4|webm|mov)(\?|$)/i.test(String(src))) {
        media = document.createElement('video')
        media.src = src
        media.autoplay = true
        media.muted = true
        media.playsInline = true
        media.loop = w.loop !== false
        try { media.playbackRate = Number(w.speed) || 1 } catch (e) { /* noop */ }
      } else {
        media = document.createElement('img')
        media.src = src
      }
      media.style.cssText = 'width:100%;height:100%;object-fit:' + (fitMap[w.fit] || 'cover') + ';'
      layer.appendChild(media)
    } catch (e) { /* wallpaper unavailable */ }
  }

  const PRTS_CSS = `
  #prtsWallpaperLayer { position:fixed; inset:0; z-index:0; overflow:hidden; pointer-events:none; }
  body[data-glass='off'] * { backdrop-filter: none !important; -webkit-backdrop-filter: none !important; }
  /* PRTS liquid glass on dsh-web surfaces (composer card + conversation) */
  .prts-glass { background: color-mix(in srgb, var(--dsw-alias-bg-overlay) 78%, transparent) !important; backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px); }
  .prtsGlassCard { background: color-mix(in srgb, var(--dsw-alias-bg-overlay) 72%, transparent) !important; backdrop-filter: blur(var(--prts-blur, 12px)); -webkit-backdrop-filter: blur(var(--prts-blur, 12px)); border-radius: 12px; }
  /* composer pinned to the bottom of the column (empty state included) */
  .prtsComposerPin { position: absolute !important; left: 0; right: 0; bottom: 0; padding: 8px 16px 14px !important; background: linear-gradient(to top, var(--dsw-alias-bg-base) 62%, transparent) !important; }
  .prtsComposerPin textarea { min-height: 60px !important; padding: 12px 14px !important; }
  body[data-glass='off'] .prtsGlassCard { background: var(--dsw-alias-bg-overlay) !important; }
  /* PRTS panel overlay */
  .prtsOverlay { position: fixed; inset: 0; z-index: 300; display: flex; align-items: center; justify-content: center; background: rgba(0,0,0,0.5); }
  .prtsCard { width: min(760px, calc(100vw - 40px)); height: min(640px, calc(100vh - 60px)); display: flex; flex-direction: column; background: color-mix(in srgb, var(--dsw-alias-bg-overlay) 88%, transparent); backdrop-filter: blur(20px); border: 1px solid var(--dsw-alias-border-l2); border-radius: 14px; overflow: hidden; }
  .prtsCardHead { display: flex; align-items: center; gap: 10px; padding: 12px 16px; border-bottom: 1px solid var(--dsw-alias-border-l1); }
  .prtsTitle { font-size: 12px; letter-spacing: 0.22em; color: var(--dsw-alias-label-primary); }
  .prtsBody { flex: 1; min-height: 0; overflow-y: auto; padding: 14px 16px; }
  .prtsSearch { position: sticky; top: 0; z-index: 2; display: flex; align-items: center; gap: 8px; height: 34px; padding: 0 10px; margin-bottom: 10px; border: 1px solid var(--dsw-alias-border-l2); border-radius: 8px; background: var(--dsw-alias-bg-overlay); }
  .prtsSearch input { flex: 1; border: none; outline: none; background: transparent; color: var(--dsw-alias-label-primary); font-size: 13px; }
  .prtsGrid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 10px; }
  .prtsItem { border: 1px solid var(--dsw-alias-border-l1); border-radius: 10px; padding: 10px 12px; display: flex; flex-direction: column; gap: 6px; background: var(--dsw-alias-bg-layer-1); }
  .prtsItemName { font-size: 13px; color: var(--dsw-alias-label-primary); }
  .prtsItemDesc { font-size: 11px; color: var(--dsw-alias-label-secondary); line-height: 1.5; }
  .prtsBtn { display: inline-flex; align-items: center; gap: 6px; height: 32px; padding: 0 14px; border: 1px solid var(--dsw-alias-border-l1); border-radius: 8px; background: transparent; color: var(--dsw-alias-label-primary); font-size: 12.5px; cursor: pointer; }
  .prtsBtn:hover:not(:disabled) { background: var(--dsw-alias-bg-layer-1); border-color: var(--dsw-alias-border-l2); }
  .prtsBtn.primary { background: var(--dsw-alias-brand-primary); color: var(--dsw-alias-bg-base); border-color: transparent; }
  .prtsBtn:disabled { opacity: 0.4; cursor: default; }
  .prtsChip { height: 28px; padding: 0 12px; border: 1px solid var(--dsw-alias-border-l1); border-radius: 8px; background: transparent; color: var(--dsw-alias-label-secondary); font-size: 11.5px; cursor: pointer; }
  .prtsChip:hover { background: var(--dsw-alias-bg-layer-1); }
  .prtsChip.on { border-color: var(--dsw-alias-brand-primary); color: var(--dsw-alias-brand-primary); }
  .prtsRow { display: flex; align-items: center; gap: 8px; margin: 6px 0; }
  .prtsLabel { flex: 1; font-size: 12px; color: var(--dsw-alias-label-secondary); }
  .prtsInput { height: 30px; padding: 0 10px; border: 1px solid var(--dsw-alias-border-l1); border-radius: 8px; background: var(--dsw-alias-bg-layer-1); color: var(--dsw-alias-label-primary); font-size: 12px; outline: none; }
  .prtsOnboard { position: fixed; inset: 0; z-index: 400; display: flex; align-items: center; justify-content: center; background: rgba(0,0,0,0.62); }
  .prtsOnboardCard { width: min(480px, calc(100vw - 40px)); padding: 26px 28px; border: 1px solid var(--dsw-alias-border-l2); border-radius: 16px; background: var(--dsw-alias-bg-overlay); display: flex; flex-direction: column; gap: 12px; }
  .prtsOnboardTitle { font-size: 16px; color: var(--dsw-alias-label-primary); letter-spacing: 0.06em; }
  .prtsOnboardBody { font-size: 12px; color: var(--dsw-alias-label-secondary); line-height: 1.7; }
  .prtsDiamond { display: inline-block; width: 9px; height: 9px; transform: rotate(45deg); border: 1.2px solid var(--dsw-alias-brand-primary); }
  `

  let styleEl = null
  function ensureCss() {
    if (styleEl) return
    styleEl = document.createElement('style')
    styleEl.id = 'prts-client-css'
    styleEl.textContent = PRTS_CSS
    document.head.appendChild(styleEl)
  }
  ensureCss()

  let lastSkinCfg = null
  getConfig().then((cfg) => { lastSkinCfg = cfg; return applySkin(cfg) }).catch(() => {})
  // the light/dark toggle (logo row + 通用设置) re-applies the skin so the
  // preset palette and the fixed ink adapt instantly
  if (ctx && typeof ctx.on === 'function') {
    ctx.on('theme/change', () => { if (lastSkinCfg) applySkin(lastSkinCfg) })
  }

  /* ---------- helpers ---------- */
  function t(key) { return key }

  function h(tag, props, ...kids) {
    return R.createElement(tag, props || null, ...(kids || []))
  }

  const CATALOG = typeof SILL === 'string' && SILL !== '__SKILL_CATALOG__' ? JSON.parse(SILL) : []

  /* ---------- 动效 (motion plugin) settings ---------- */
  function MotionSettings() {
    const [cfg, setCfg] = useState({ ui: {} })
    useEffect(() => { getConfig().then((c) => setCfg(c || { ui: {} })) }, [])
    const save = async (patch) => {
      const next = { ...cfg, ...patch, ui: { ...(cfg.ui || {}), ...((patch && patch.ui) || {}) } }
      setCfg(next)
      await setConfig(next)
      applySkin(next)
    }
    const ui = cfg.ui || {}
    return h('div', { className: 'prtsBody' },
      h('div', { className: 'prtsGroup' },
        h('div', { className: 'prtsGroupHead', style: { cursor: 'default' } }, h('span', { className: 'prtsGroupTitle' }, '侧边栏抽屉')),
        h('div', { className: 'prtsGroupBody' },
          h('div', { className: 'prtsRow' },
            h('span', { className: 'prtsLabel' }, '抽屉动效'),
            h('input', { type: 'checkbox', checked: ui.drawer !== false, onChange: (e) => save({ ui: { ...ui, drawer: e.target.checked } }) }),
          ),
          ui.drawer !== false ? h('div', { className: 'prtsRow' }, h('span', { className: 'prtsLabel' }, '速度'),
            h('input', { type: 'range', min: 200, max: 800, step: 20, value: String(ui.drawerMs || 380), style: { flex: 2 }, onChange: (e) => save({ ui: { ...ui, drawerMs: Number(e.target.value) } }) }),
          ) : null,
          h('div', { className: 'prtsItemDesc', style: { marginTop: 6 } }, '侧边栏与聊天、输入框、背景不在同一图层 —— 收放像拉抽屉一样，不影响其他任何部件；将来新加入的侧栏类插件也能直接套用这套动效。'),
        ),
      ),
      h('div', { className: 'prtsGroup' },
        h('div', { className: 'prtsGroupHead', style: { cursor: 'default' } }, h('span', { className: 'prtsGroupTitle' }, '律动')),
        h('div', { className: 'prtsGroupBody' },
          h('div', { className: 'prtsRow' },
            h('button', { className: 'prtsBtn' + (ui.beat ? ' on' : ''), onClick: async () => {
              if (ui.beat) { stopBeat(); await save({ ui: { ...ui, beat: false } }); return }
              const ok = await startBeat()
              if (ok) await save({ ui: { ...ui, beat: true } })
              else alert('无法捕获系统声音 —— 请在弹窗中选择「整个屏幕」并勾选系统音频。')
            } }, ui.beat ? '关闭律动' : '开启系统声音律动'),
            h('span', { className: 'prtsItemDesc' }, '背景菱形与方块随电脑正在播放的声音振动'),
          ),
        ),
      ),
    )
  }

  /* ---------- PRTS settings section (wallpaper / theme / sound / updates) ---------- */
  const THEME_PRESETS = [
    ['tokyonight', 'Tokyo Night', '#7aa2f7'],
    ['nord', 'Nord', '#88c0d0'],
    ['dracula', 'Dracula', '#bd93f9'],
    ['rose-pine', 'Rosé Pine', '#ebbcba'],
    ['catppuccin', 'Catppuccin', '#89b4fa'],
    ['gruvbox', 'Gruvbox', '#83a598'],
  ]
  function PrtsSettings() {
    const [cfg, setCfg] = useState({ ui: {} })
    const [wpOpen, setWpOpen] = useState(false)
    useEffect(() => { getConfig().then((c) => setCfg(c || { ui: {} })) }, [])
    const save = async (patch) => {
      const next = { ...cfg, ...patch, ui: { ...(cfg.ui || {}), ...((patch && patch.ui) || {}) } }
      setCfg(next)
      await setConfig(next)
      await applySkin(next)
    }
    const ui = cfg.ui || {}
    const w = ui.wallpaper || {}
    const preset = ui.theme || ''

    /* ---- wallpaper engine (detect / list / pick) ---- */
    const [weState, setWeState] = useState(null)
    const detectWe = async () => {
      setWeState({ busy: true })
      try {
        const r = await api('POST', '/prts/api/http', { method: 'GET', url: 'http://127.0.0.1:35585/v2/wallpapers' })
        let j = null
        try { j = JSON.parse((r && r.text) || '') } catch (e) { /* shape unknown */ }
        const list = (j && (j.wallpapers || j.items || (Array.isArray(j) ? j : null))) || []
        setWeState({ busy: false, list: list.map((it) => ({ id: it.id, title: it.title || it.name || String(it.id) })) })
      } catch (e) { setWeState({ busy: false, error: String((e && e.message) || e) }) }
    }
    const uploadWall = (file) => {
      const reader = new FileReader()
      reader.onload = async () => {
        const m = /^data:([^;]+);base64,(.*)$/.exec(String(reader.result || ''))
        if (!m) return
        const mime = m[1]
        const ext = mime.indexOf('video') === 0 ? 'mp4' : (mime === 'image/png' ? 'png' : 'jpg')
        const name = 'wall-' + Date.now().toString(36) + '.' + ext
        await api('POST', '/prts/api/wallpaper', { file: name, mime, base64: m[2] })
        await save({ ui: { ...ui, wallpaper: { ...w, file: name, url: '', type: mime.indexOf('video') === 0 ? 'video' : 'image', mime, fit: w.fit || 'cover', opacity: w.opacity !== undefined ? w.opacity : 1 } } })
      }
      reader.readAsDataURL(file)
    }

    return h('div', { className: 'prtsBody' },
      /* ================= wallpaper ================= */
      h('div', { className: 'prtsGroup' },
        h('button', { className: 'prtsGroupHead', onClick: () => setWpOpen(!wpOpen) },
          h('span', { className: 'prtsGroupTitle' }, '壁纸'),
          h('span', { className: 'prtsGroupSub' }, w.file || w.url ? '已设置' : '未设置'),
          h('span', { className: 'prtsChev' }, wpOpen ? '▾' : '▸'),
        ),
        wpOpen ? h('div', { className: 'prtsGroupBody' },
          h('div', { className: 'prtsRow' },
            h('label', { className: 'prtsBtn', style: { cursor: 'pointer' } },
              '上传图片 / 视频',
              h('input', { type: 'file', accept: 'image/*,video/*', style: { display: 'none' }, onChange: (e) => { const f = e.target.files && e.target.files[0]; if (f) uploadWall(f) } }),
            ),
            h('button', { className: 'prtsBtn', disabled: !!(weState && weState.busy), onClick: detectWe }, weState && weState.busy ? '检测中…' : '连接 Wallpaper Engine'),
            (w.file || w.url) ? h('button', { className: 'prtsBtn', onClick: async () => { await api('DELETE', '/prts/api/wallpaper').catch(() => {}); await save({ ui: { ...ui, wallpaper: { ...w, file: '', url: '' } } }) } }, '清除') : null,
          ),
          weState && weState.error ? h('div', { className: 'prtsItemDesc', style: { marginTop: 6 } }, '未检测到 Wallpaper Engine（需在其设置中开启 HTTP API）') : null,
          weState && weState.list && weState.list.length ? h('div', { className: 'prtsRow' },
            h('select', { className: 'prtsInput', style: { flex: 2 }, defaultValue: '', onChange: (e) => {
              const id = e.target.value
              if (id) save({ ui: { ...ui, wallpaper: { ...w, url: 'http://127.0.0.1:35585/v2/stream/' + encodeURIComponent(id), fit: w.fit || 'cover', type: 'video' } } })
            } },
              h('option', { value: '' }, '选择一张 Wallpaper Engine 壁纸'),
              weState.list.map((it) => h('option', { key: it.id, value: it.id }, it.title)),
            ),
          ) : null,
          (w.file || w.url) ? h('div', {},
            h('div', { className: 'prtsRow' }, h('span', { className: 'prtsLabel' }, '填充方式'),
              h('select', { className: 'prtsInput', value: w.fit || 'cover', onChange: (e) => save({ ui: { ...ui, wallpaper: { ...w, fit: e.target.value } } }) },
                h('option', { value: 'cover' }, '覆盖'), h('option', { value: 'fill' }, '填充'), h('option', { value: 'free' }, '自由'), h('option', { value: 'contain' }, '居中')),
            ),
            h('div', { className: 'prtsRow' }, h('span', { className: 'prtsLabel' }, '透明度'),
              h('input', { type: 'range', min: 0, max: 1, step: 0.01, value: String(w.opacity !== undefined ? w.opacity : 1), style: { flex: 2 }, onChange: (e) => save({ ui: { ...ui, wallpaper: { ...w, opacity: Number(e.target.value) } } }) }),
            ),
          ) : null,
          h('div', { className: 'prtsRow' },
            h('span', { className: 'prtsLabel' }, '背景模糊'),
            h('input', { type: 'checkbox', checked: ui.glass !== false, onChange: (e) => save({ ui: { ...ui, glass: e.target.checked } }) }),
          ),
          ui.glass !== false ? h('div', { className: 'prtsRow' }, h('span', { className: 'prtsLabel' }, '模糊程度'),
            h('input', { type: 'range', min: 0, max: 24, step: 1, value: String(ui.blur !== undefined ? ui.blur : 12), style: { flex: 2 }, onChange: (e) => save({ ui: { ...ui, blur: Number(e.target.value) } }) }),
          ) : null,
        ) : null,
      ),

      /* ================= theme (presets only) ================= */
      h('div', { className: 'prtsGroup' },
        h('div', { className: 'prtsGroupHead', style: { cursor: 'default' } }, h('span', { className: 'prtsGroupTitle' }, '主题')),
        h('div', { className: 'prtsGroupBody' },
          h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: 6 } },
            h('button', { key: 'default', className: 'prtsChip' + (!preset ? ' on' : ''), onClick: () => save({ ui: { ...ui, theme: '' } }) }, '系统默认'),
            THEME_PRESETS.map(([id, name]) => h('button', { key: id, className: 'prtsChip' + (preset === id ? ' on' : ''), onClick: () => save({ ui: { ...ui, theme: id } }) }, name)),
          ),
          h('div', { className: 'prtsItemDesc', style: { marginTop: 8 } }, '预设只着色文字、按钮、描边与背景色调；与通用设置里的白天 / 黑夜 / 跟随系统互不冲突，切换后预设自动适配明暗。'),
        ),
      ),

      /* ================= sound beat ================= */
      h('div', { className: 'prtsGroup' },
        h('div', { className: 'prtsGroupHead', style: { cursor: 'default' } }, h('span', { className: 'prtsGroupTitle' }, '声音律动')),
        h('div', { className: 'prtsGroupBody' },
          h('div', { className: 'prtsRow' },
            h('button', { className: 'prtsBtn' + (ui.beat ? ' on' : ''), onClick: async () => {
              if (ui.beat) { stopBeat(); await save({ ui: { ...ui, beat: false } }); return }
              const ok = await startBeat()
              if (ok) await save({ ui: { ...ui, beat: true } })
              else alert('无法捕获系统声音 —— 请在弹窗中选择「整个屏幕」并勾选系统音频。')
            } }, ui.beat ? '关闭律动' : '开启系统声音律动'),
            h('span', { className: 'prtsItemDesc' }, '背景菱形与方块随电脑正在播放的声音振动'),
          ),
        ),
      ),

      /* ================= updates ================= */
      h('div', { className: 'prtsGroup' },
        h(UpdateRow, {}),
      ),
    )
  }
  /* ---------- stable-channel updates ---------- */
  function UpdateRow() {
    const [info, setInfo] = useState(null)   // { current, latest, update, channel }
    const [busy, setBusy] = useState(false)
    const [msg, setMsg] = useState('')
    const refresh = useCallback(async () => {
      try { setInfo(await api('GET', '/prts/api/update-check')) } catch (e) { setInfo({ current: '?', latest: '?', update: false }) }
    }, [])
    useEffect(() => { refresh() }, [refresh])
    const doUpdate = async () => {
      setBusy(true); setMsg('更新中…')
      try {
        const r = await api('POST', '/prts/api/update')
        if (r && r.ok && r.updated) { setMsg('已更新到 v' + r.version + ' — 重启 PRTS 生效'); setInfo({ ...info, current: r.version, update: false }) }
        else if (r && r.ok && !r.updated) setMsg('已是最新版本')
        else setMsg((r && r.error) || '更新失败')
      } catch (e) { setMsg(String((e && e.message) || e)) }
      setBusy(false)
    }
    const has = !!(info && info.update)
    return h('div', {},
      h('div', { className: 'prtsTitle', style: { margin: '14px 0 6px' } }, '更新'),
      h('div', { className: 'prtsRow' },
        h('span', { className: 'prtsLabel' },
          info === null ? '检查中…'
            : has ? '发现稳定版 v' + info.latest + '（当前 v' + info.current + '）'
              : '已是最新稳定版 v' + (info.current || '?')),
        has ? h('button', { className: 'prtsBtn primary', disabled: busy, onClick: doUpdate }, busy ? '更新中…' : '立即更新') : null,
        !has && info !== null ? h('button', { className: 'prtsBtn', disabled: busy, onClick: () => { setInfo(null); refresh() } }, '检查更新') : null,
      ),
      msg ? h('div', { className: 'prtsItemDesc', style: { marginTop: 4 } }, msg) : null,
      h('div', { className: 'prtsItemDesc', style: { marginTop: 2 } }, '仅跟随稳定版发布（网站下载同源）；git 现行版不会推送。'),
    )
  }

  /* ---------- balance panel ---------- */
  function BalancePanel() {
    const [cfg, setCfg] = useState({ deepseek: {} })
    const [bal, setBal] = useState(null)
    const [key, setKey] = useState('')
    const [err, setErr] = useState('')
    const [logging, setLogging] = useState(false)
    useEffect(() => { getConfig().then((c) => setCfg(c || { deepseek: {} })) }, [])
    const ds = cfg.deepseek || {}
    const refresh = useCallback(async () => {
      if (!ds.apiKey) { setBal(null); return }
      try {
        const res = await api('POST', '/prts/api/http', { method: 'GET', url: 'https://api.deepseek.com/user/balance', headers: { Authorization: 'Bearer ' + ds.apiKey } })
        const d = JSON.parse((res && res.text) || '{}')
        const infos = d.balance_infos || []
        const cny = infos.find((i) => i.currency === 'CNY') || infos[0]
        setBal(cny ? Number(cny.total_balance || 0) : null)
        setErr('')
      } catch (e) { setErr(String(e && e.message || e)) }
    }, [ds.apiKey])
    useEffect(() => { refresh() }, [refresh])
    const saveDs = async (patch) => {
      const next = { ...cfg, deepseek: { ...ds, ...patch } }
      setCfg(next)
      await setConfig(next)
      refresh()
    }
    const loginDeepseek = async () => {
      setLogging(true)
      try {
        const bridge = window.prts && window.prts.bridge
        // Exactly ONE window: the native Electron login window when the
        // bridge exists, or a single browser tab otherwise — never both.
        if (bridge && typeof bridge.loginDeepseek === 'function') {
          const r = await bridge.loginDeepseek()
          if (r && r.apiKey) { await saveDs({ apiKey: r.apiKey, loggedIn: true }); setLogging(false); return }
          setLogging(false)
          return
        }
        window.open('https://platform.deepseek.com/sign_in', '_blank')
      } catch (e) { /* manual input stays available */ }
      setLogging(false)
    }
    return h('div', {},
      bal !== null ? h('div', { className: 'prtsItemName', style: { fontSize: 24, fontFamily: 'monospace' } }, '¥ ' + bal.toLocaleString('zh-CN', { minimumFractionDigits: 2 })) : h('div', { className: 'prtsItemDesc' }, ds.apiKey ? (err || '读取中…') : '登录 DeepSeek 开发者账号后显示人民币余额'),
      !ds.apiKey ? h('div', { className: 'prtsRow' },
        h('button', { className: 'prtsBtn primary', disabled: logging, onClick: loginDeepseek }, logging ? '等待网页登录…' : '登录 DeepSeek 开发者账号'),
      ) : null,
      h('div', { className: 'prtsRow' },
        h('input', { className: 'prtsInput', style: { flex: 2 }, type: 'password', value: key, placeholder: 'DeepSeek API Key (sk-…)', onChange: (e) => setKey(e.target.value) }),
        h('button', { className: 'prtsBtn primary', onClick: async () => {
          const k = key.trim()
          if (!k) return
          const res = await api('POST', '/prts/api/http', { method: 'GET', url: 'https://api.deepseek.com/user/balance', headers: { Authorization: 'Bearer ' + k } })
          if (res && res.status === 200) { await saveDs({ apiKey: k, loggedIn: true }); setKey('') }
          else alert('API Key 无效')
        } }, '保存'),
      ),
      h('div', { className: 'prtsRow' },
        h('button', { className: 'prtsBtn', onClick: () => window.open('https://platform.deepseek.com/top_up', '_blank') }, '充值'),
        h('button', { className: 'prtsBtn', onClick: () => window.open('https://platform.deepseek.com/api_keys', '_blank') }, 'API Keys'),
        h('button', { className: 'prtsBtn', onClick: () => saveDs({ apiKey: '', loggedIn: false }) }, '登出'),
      ),
    )
  }

  /* ---------- first-run API-key onboarding ---------- */
  function Onboarding({ onDone }) {
    const [cfg, setCfg] = useState(null)
    const [key, setKey] = useState('')
    const [busy, setBusy] = useState(false)
    useEffect(() => { getConfig().then((c) => setCfg(c || {})) }, [])
    const finish = async (cfg2) => {
      await setConfig({ ...cfg2, ui: { ...(cfg2 && cfg2.ui), onboardedApiKey: true } })
      if (onDone) onDone()
    }
    if (cfg === null) return null
    const createAccount = async () => {
      setBusy(true)
      try {
        const bridge = window.prts && window.prts.bridge
        // Exactly ONE window: native Electron login when the bridge exists,
        // otherwise a single browser tab — never both at once.
        if (bridge && typeof bridge.loginDeepseek === 'function') {
          const r = await bridge.loginDeepseek()
          if (r && r.apiKey) {
            await setConfig({ ...cfg, deepseek: { ...(cfg.deepseek || {}), apiKey: r.apiKey, loggedIn: true } })
            await finish(cfg)
            setBusy(false)
            return
          }
          setBusy(false)
          return
        }
        window.open('https://platform.deepseek.com/sign_in', '_blank')
        await finish(cfg)
      } catch (e) { /* manual path */ }
      setBusy(false)
    }
    const saveKey = async () => {
      const k = key.trim()
      if (!k) return
      setBusy(true)
      try {
        const res = await api('POST', '/prts/api/http', { method: 'GET', url: 'https://api.deepseek.com/user/balance', headers: { Authorization: 'Bearer ' + k } })
        if (res && res.status === 200) {
          await setConfig({ ...cfg, deepseek: { ...(cfg.deepseek || {}), apiKey: k, loggedIn: true } })
          await finish(cfg)
        } else alert('API Key 无效')
      } catch (e) { alert(String((e && e.message) || e)) }
      setBusy(false)
    }
    return h('div', { className: 'prtsOnboard' },
      h('div', { className: 'prtsOnboardCard' },
        h('div', { className: 'prtsOnboardTitle' }, '欢迎，博士'),
        h('div', { className: 'prtsOnboardBody' }, '在使用 PRTS 之前 —— 请问你有 DeepSeek API Key 吗？'),
        h('div', { className: 'prtsRow' },
          h('input', { className: 'prtsInput', style: { flex: 2 }, type: 'password', value: key, placeholder: '有 —— 粘贴 API Key (sk-…)', onChange: (e) => setKey(e.target.value) }),
          h('button', { className: 'prtsBtn primary', disabled: busy || !key.trim(), onClick: saveKey }, '保存'),
        ),
        h('div', { style: { display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 8 } },
          h('button', { className: 'prtsBtn', disabled: busy, onClick: createAccount }, busy ? '等待网页登录…' : '没有 —— 去 DeepSeek 官网创建'),
          h('button', { className: 'prtsBtn', disabled: busy, onClick: () => finish(cfg) }, '稍后'),
        ),
      ),
    )
  }

  /* ---------- registrations ---------- */
  // The slot registrations need the client slot registry. The skin layer
  // below runs regardless — only these additive UI contributions are
  // conditional. The left sidebar keeps ONLY dsh-web's own settings button;
  // PRTS adds nothing else to the footer.

  const openNativeSettings = () => {
    const btns = [...document.querySelectorAll('button')]
    const hit = btns.find((b) => /^(设置|settings)$/i.test((b.title || b.textContent || '').trim().slice(0, 8))) ||
      btns.find((b) => /settings/i.test((b.getAttribute('aria-label') || '') + ' ' + (b.className || ''))) ||
      // dsh-web's own settings trigger is an icon-only button in the sidebar
      // footer (hashed class names; the 'trigger' substring survives builds).
      btns.find((b) => /trigger/i.test(String(b.className || '')))
    if (hit) { try { hit.click() } catch (e) { /* noop */ } }
  }
  const jumpToSection = (label, id) => {
    openNativeSettings()
    setTimeout(() => {
      const items = [...document.querySelectorAll('button, [role="tab"], [class*="nav"] span, [class*="Nav"] span')]
      const hit = items.find((el) => {
        const t = (el.textContent || '').trim()
        return t && (t === label || (id && (el.dataset && (el.dataset.id === id || el.dataset.section === id))))
      })
      if (hit) { try { hit.click() } catch (e) { /* noop */ } }
    }, 400)
  }
  const sectionRows = () => {
    try {
      const raw = slots && slots.entries ? slots.entries('settings.section') : []
      return raw.map((e) => {
        const opt = (e && e.options) || {}
        const id = String(opt.id || (e && e.id) || '')
        let label = opt.label
        if (typeof label === 'function') { try { label = label() } catch (err) { label = null } }
        label = String(label == null ? '' : label)
        return { id, order: Number(opt.order) || 0, label: label || id }
      }).sort((a, b) => a.order - b.order)
    } catch (e) { return [] }
  }

  if (slots !== undefined) {
    // PRTS settings section (wallpaper / theme / sound / updates)
    slots.inject('settings.section', () => {
      return slots.register({ name: 'settings.section', id: 'prts', order: 90, label: 'PRTS' }, (props) => {
        return h('div', { className: 'prtsBody', style: { maxHeight: 'calc(100vh - 200px)', overflowY: 'auto' } },
          h(PrtsSettings, {}),
        )
      })
    })
    // 动效 — the motion plugin's own settings page (drawer / spring / beat)
    slots.inject('settings.section', () => {
      return slots.register({ name: 'settings.section', id: 'prts-motion', order: 92, label: '动效' }, (props) => {
        return h('div', { className: 'prtsBody', style: { maxHeight: 'calc(100vh - 200px)', overflowY: 'auto' } },
          h(MotionSettings, {}),
        )
      })
    })
    // Balance is its own settings page (a "plugin" section) — 余额
    slots.inject('settings.section', () => {
      return slots.register({ name: 'settings.section', id: 'prts-balance', order: 91, label: '余额' }, (props) => {
        return h('div', { className: 'prtsBody', style: { maxHeight: 'calc(100vh - 200px)', overflowY: 'auto' } },
          h(BalancePanel, {}),
        )
      })
    })
  }

  /** Hover popup above the native settings button: the pages the settings
   *  panel actually has (通用设置/模型/插件/Agent预设/余额/PRTS + whatever
   *  later plugins add) pop UP in a vertical stack aligned with the button.
   *  Fixed overlay — it never shifts the layout. */
  function settingsHoverPopup() {
    let pop = null
    let hideTimer = null
    const findTrigger = () => {
      const btns = [...document.querySelectorAll('button')]
      return btns.find((b) => /trigger/i.test(String(b.className || ''))) || null
    }
    // icon per settings section — custom minimal glyphs, no labels
    const sectionIcon = (id) => {
      const ic = (inner) => '<svg width="15" height="15" viewBox="0 0 15 15" fill="none">' + inner + '</svg>'
      if (id === 'general') return ic('<path d="M2 4.5h11M2 7.5h11M2 10.5h11" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/><circle cx="5" cy="4.5" r="1.5" fill="currentColor" stroke="none"/><circle cx="10" cy="7.5" r="1.5" fill="currentColor" stroke="none"/><circle cx="7" cy="10.5" r="1.5" fill="currentColor" stroke="none"/>')
      if (id === 'models') return ic('<path d="M7.5 2 13 5l-5.5 3L2 5l5.5-3Z" stroke="currentColor" stroke-width="1.1" stroke-linejoin="round"/><path d="M2 8.2 7.5 11l5.5-2.8M2 11l5.5 2.8L13 11" stroke="currentColor" stroke-width="1.1" stroke-linejoin="round"/>')
      if (id === 'plugins' || /plugin/.test(id)) return ic('<path d="M6.2 8.8 8.8 6.2a2 2 0 0 0 2.9-2.7l-1.6 1.6-2.1-.3-.3-2.1 1.6-1.6A2 2 0 0 0 6.2 4L3.6 6.6a1 1 0 0 1-1.3.2L2 7l1.2 1.2 1.6-1.6a1 1 0 0 1 1.4 0l1 1 .9.9Z" stroke="currentColor" stroke-width="1.1" stroke-linejoin="round"/>')
      if (id === 'agent-presets') return ic('<rect x="4" y="6.5" width="7" height="5" rx="1.6" stroke="currentColor" stroke-width="1.1"/><path d="M7.5 6.5V4.6M5.6 4.6h3.8" stroke="currentColor" stroke-width="1.1" stroke-linecap="round"/><circle cx="6.1" cy="9" r=".7" fill="currentColor"/><circle cx="8.9" cy="9" r=".7" fill="currentColor"/>')
      if (id === 'prts') return ic('<path d="M7.5 1.8 13.2 7.5 7.5 13.2 1.8 7.5Z" stroke="currentColor" stroke-width="1.2"/><rect x="5.9" y="5.9" width="3.2" height="3.2" fill="currentColor"/>')
      if (id === 'prts-motion') return ic('<path d="M2 8.5c2-4 4.5-4 6.5 0s4.5 4 6.5 0" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" fill="none"/>')
      if (id === 'prts-balance') return ic('<circle cx="7.5" cy="7.5" r="5.5" stroke="currentColor" stroke-width="1.2"/><path d="M7.5 4.2v6.6M5.4 6h4.2M5.4 9h4.2" stroke="currentColor" stroke-width="1.1" stroke-linecap="round"/>')
      return ic('<rect x="2.5" y="2.5" width="10" height="10" rx="1.8" stroke="currentColor" stroke-width="1.1"/><path d="M7.5 2.5v3l3-3" stroke="currentColor" stroke-width="1.1" fill="none"/>')
    }
    const show = () => {
      const trig = findTrigger()
      if (!trig) return
      clearTimeout(hideTimer)
      if (pop) return
      const r = trig.getBoundingClientRect()
      pop = document.createElement('div')
      pop.className = 'prtsHoverPop'
      pop.style.position = 'fixed'
      pop.style.left = Math.max(4, Math.round(r.left + r.width / 2 - 17)) + 'px'
      pop.style.top = (r.top - 6) + 'px'
      pop.style.transform = 'translateY(-100%)'
      const rows = sectionRows()
      for (const sec of rows) {
        const b = document.createElement('button')
        b.type = 'button'
        b.title = sec.label
        b.innerHTML = sectionIcon(sec.id) + '<span>' + sec.label + '</span>'
        b.addEventListener('click', () => { hide(); jumpToSection(sec.label, sec.id) })
        pop.appendChild(b)
      }
      if (!rows.length) { pop.remove(); pop = null; return }
      document.body.appendChild(pop)
      pop.addEventListener('mouseenter', () => clearTimeout(hideTimer))
      pop.addEventListener('mouseleave', scheduleHide)
    }
    const scheduleHide = () => { clearTimeout(hideTimer); hide() }
    const hide = () => { if (pop) { pop.remove(); pop = null } }
    document.addEventListener('mousemove', (e) => {
      const trig = findTrigger()
      if (!trig) { scheduleHide(); return }
      const r = trig.getBoundingClientRect()
      const pad = 40
      const near = e.clientX >= r.left - pad && e.clientX <= r.right + pad && e.clientY >= r.top - pad * 2 && e.clientY <= r.bottom + pad
      if (near) show()
      else scheduleHide()
    })
    // re-bind direct hover as dsh-web re-renders replace the trigger
    setInterval(() => {
      const trig = findTrigger()
      if (!trig || trig.dataset.prtsHover) return
      trig.dataset.prtsHover = '1'
      trig.addEventListener('mouseenter', show)
      trig.addEventListener('mouseleave', scheduleHide)
    }, 1500)
  }
  settingsHoverPopup()

  // onboarding (first run, any port)  // onboarding (first run) — only AFTER the intro has fully played out and
  // the app has formally entered; never during the animation.
  let onboardingShown = false
  function showOnboarding() { getConfig().then(async (cfg) => {
    if (onboardingShown) return
    onboardingShown = true
    const ui = (cfg && cfg.ui) || {}
    if (ui.onboardedApiKey) return
    // check whether a key is already configured (PRTS copy)
    const ds = cfg && cfg.deepseek
    if (ds && ds.apiKey) {
      await setConfig({ ...cfg, ui: { ...ui, onboardedApiKey: true } })
      return
    }
    // render the onboarding overlay once
    const mount = document.createElement('div')
    mount.id = 'prts-onboard-mount'
    document.body.appendChild(mount)
    const root = createRoot ? createRoot(mount) : null
    const finish = async () => {
      if (root && root.unmount) root.unmount()
      mount.remove()
    }
    const el = h(Onboarding, { onDone: finish })
    if (root && root.render) root.render(el)
  }).catch(() => {}) }

  /* ============================================================
     PRTS skin layer — everything visual that makes dsh-web look
     like PRTS: brand swap (no whale), hero, particle intro,
     composer expand button, background diamond/square, voice,
     PRTS-styled controls and the sidebar widget dock.
     ============================================================ */

  const SKIN_CSS = `
  /* PRTS-styled controls on dsh-web — every plugin button lands here */
  button, [role='button'], [class*='btn'], [class*='button'], [class*='Button'] {
    border-radius: 8px !important;
    border-color: var(--dsw-alias-border-l2) !important;
  }
  button:hover, [role='button']:hover { filter: brightness(1.12); }
  textarea { border-radius: 10px !important; }
  ::-webkit-scrollbar { width: 8px; height: 8px; }
  ::-webkit-scrollbar-thumb { background: var(--dsw-alias-border-l2); border-radius: 4px; }
  ::-webkit-scrollbar-thumb:hover { background: var(--dsw-alias-label-secondary); }
  /* PRTS brand (no whale) */
  .prtsBrand { display: inline-flex; align-items: center; gap: 8px; font-style: italic; letter-spacing: 0.22em; font-weight: 600; font-size: 15px; color: var(--dsw-alias-label-primary); }
  .prtsBrand .rhombus { width: 13px; height: 13px; border: 1.5px solid var(--prts-diamond, var(--dsw-alias-brand-primary)); transform: rotate(45deg); }
  .prtsBrand .rhombus::after { content: ''; position: absolute; inset: 3px; background: var(--prts-diamond, var(--dsw-alias-brand-primary)); }
  /* hero: sits exactly at the centre of the permanent background square */
  .prtsHero { position: fixed; left: 50%; top: 50%; transform: translate(-50%, -50%); display: flex; flex-direction: column; align-items: center; gap: 12px; color: var(--prts-ink, #FAFAFA); pointer-events: none; }
  .prtsHero .row { display: flex; align-items: center; gap: 14px; }
  .prtsHeroMark { position: relative; display: inline-block; width: 64px; height: 64px; border: 1.5px solid var(--prts-ink, #FAFAFA); transform: rotate(45deg); }
  .prtsHeroMark .sq { position: absolute; inset: 30%; background: var(--prts-ink, #FAFAFA); transform: rotate(-45deg); }
  .prtsHero .word { font-style: italic; font-weight: 600; letter-spacing: 0.3em; font-size: 40px; }
  .prtsHero .tag { font-size: 14px; letter-spacing: 0.2em; color: var(--dsw-alias-label-secondary); }
  /* background diamond & square — between the wallpaper blur and the text */
  .prtsBgMarks { position: fixed; left: 50%; top: 50%; z-index: 1; pointer-events: none; }
  .prtsBgMarks .d { position: absolute; width: 460px; height: 460px; border: 1px solid var(--prts-ink, #FAFAFA); transform: translate(-50%, -50%) rotate(45deg); opacity: 0.16; background: color-mix(in srgb, var(--prts-ink, #FAFAFA) 5%, transparent); }
  .prtsBgMarks .s { position: absolute; width: 216px; height: 216px; border: 1px solid var(--prts-ink, #FAFAFA); transform: translate(-50%, -50%); opacity: 0.14; background: color-mix(in srgb, var(--prts-ink, #FAFAFA) 5%, transparent); }
  .prtsBgMarks.vib .d { animation: prtsVib 0.16s linear infinite; }
  .prtsBgMarks.vib .s { animation: prtsVibS 0.16s linear infinite; }
  @keyframes prtsVib { 0% { transform: translate(-50%,-50%) rotate(45deg) scale(1); } 50% { transform: translate(-50%,-50%) rotate(45deg) scale(1.05); } }
  @keyframes prtsVibS { 0% { transform: translate(-50%,-50%) scale(1); } 50% { transform: translate(-50%,-50%) scale(1.07); } }
  /* audio-beat mode (system sound): JS drives --prts-beat, CSS applies it */
  .prtsBgMarks.beat .d { transform: translate(-50%,-50%) rotate(45deg) scale(calc(1 + var(--prts-beat, 0) * 0.12)); }
  .prtsBgMarks.beat .s { transform: translate(-50%,-50%) scale(calc(1 + var(--prts-beat, 0) * 0.16)); }
  /* composer expand handle: notched arrow + pulsing dots, drag-to-expand */
  .prtsExpand { position: absolute; right: 12px; top: -30px; display: flex; flex-direction: column; align-items: center; gap: 2px; padding: 3px 2px 2px; border: none; background: transparent; color: var(--prts-accent, var(--dsw-alias-brand-primary)); cursor: ns-resize; z-index: 40; touch-action: none; }
  .prtsExpand svg.arrow { display: block; filter: drop-shadow(0 0 6px color-mix(in srgb, var(--prts-accent, var(--dsw-alias-brand-primary)) 60%, transparent)); animation: prtsArrowGlow 2.4s ease-in-out infinite; }
  @keyframes prtsArrowGlow { 0%,100% { opacity: .55; } 50% { opacity: 1; } }
  .prtsExpand .dots { display: flex; gap: 3px; }
  .prtsExpand .dots i { width: 2.5px; height: 2.5px; border-radius: 50%; background: var(--prts-accent, var(--dsw-alias-brand-primary)); animation: prtsDot 1.6s ease-in-out infinite; }
  .prtsExpand .dots i:nth-child(2) { animation-delay: .2s; }
  .prtsExpand .dots i:nth-child(3) { animation-delay: .4s; }
  @keyframes prtsDot { 0%,100% { opacity: .25; transform: translateY(0); } 50% { opacity: 1; transform: translateY(1.5px); } }
  /* particle intro */
  .prtsIntro { position: fixed; inset: 0; z-index: 1000; background: var(--dsw-alias-bg-base); display: flex; align-items: center; justify-content: center; cursor: pointer; transition: opacity 0.6s ease; }
  .prtsIntro.done { opacity: 0; pointer-events: none; }
  .prtsIntro canvas { position: absolute; inset: 0; }
  .prtsIntro .txt { position: relative; z-index: 2; color: var(--dsw-alias-label-primary); font-style: italic; letter-spacing: 0.24em; font-size: 30px; opacity: 0; transition: opacity 0.5s ease; }
  .prtsIntro .txt.show { opacity: 1; }
  /* quick settings popup (pops UP above the sidebar settings button) */
  .prtsQuickWrap { position: relative; }
  .prtsQuick { position: absolute; bottom: calc(100% + 10px); right: 0; min-width: 176px; padding: 8px; border: 1px solid var(--dsw-alias-border-l2); border-radius: 12px; background: color-mix(in srgb, var(--dsw-alias-bg-overlay) 92%, transparent); backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px); box-shadow: 0 10px 34px rgba(0,0,0,.5); display: flex; flex-direction: column; gap: 3px; z-index: 60; }
  .prtsQuick button { display: flex; align-items: center; gap: 8px; height: 30px; padding: 0 10px; border: 1px solid transparent; border-radius: 8px; background: transparent; color: var(--dsw-alias-label-primary); font-size: 12px; cursor: pointer; text-align: left; }
  .prtsQuick button:hover { border-color: var(--dsw-alias-border-l2); background: var(--dsw-alias-bg-layer-1); }
  .prtsQuick .sep { height: 1px; background: var(--dsw-alias-border-l1); margin: 3px 4px; }
  /* custom window bar: full black, three circles, ALWAYS visible (browser-like);
   * the app frame is shifted down so the bar never covers the logo/buttons */
  .prtsTitlebar { position: fixed; top: 0; left: 0; right: 0; height: 34px; z-index: 5000; display: flex; align-items: center; justify-content: flex-end; padding: 0 10px; background: #0A0A0B; border-bottom: 1px solid var(--dsw-alias-border-l1); -webkit-app-region: drag; }
  .prtsTitlebar .winBtn { -webkit-app-region: no-drag; width: 26px; height: 26px; border-radius: 50%; border: 1px solid var(--dsw-alias-border-l2); background: transparent; color: var(--dsw-alias-label-primary); display: inline-flex; align-items: center; justify-content: center; font-size: 12px; line-height: 1; cursor: pointer; margin-left: 8px; padding: 0; }
  .prtsTitlebar .winBtn:hover { background: var(--dsw-alias-bg-layer-2); box-shadow: 0 0 10px rgba(250,250,250,.15); }
  .prtsTitlebar .winBtn.close:hover { background: #f7768e; color: #0A0A0B; border-color: transparent; }
  /* PRTS settings groups (dsh-settings-like cards) */
  .prtsGroup { border: 1px solid var(--dsw-alias-border-l1); border-radius: 12px; margin: 10px 0; background: var(--dsw-alias-bg-layer-1); overflow: hidden; }
  .prtsGroupHead { width: 100%; display: flex; align-items: center; gap: 8px; padding: 10px 14px; border: none; background: transparent; color: var(--dsw-alias-label-primary); cursor: pointer; text-align: left; }
  .prtsGroupTitle { font-size: 13px; font-weight: 600; letter-spacing: .04em; }
  .prtsGroupSub { margin-left: auto; font-size: 11px; color: var(--dsw-alias-label-secondary); }
  .prtsChev { color: var(--dsw-alias-label-secondary); font-size: 11px; }
  .prtsGroupBody { padding: 2px 14px 12px; }
  /* hover popup above the settings button: a bare column of small icon
   * buttons (no panel, no labels) — same height as the settings button,
   * mouse leave closes it automatically. */
  .prtsHoverPop { display: flex; flex-direction: column; padding: 0; }
  .prtsHoverPop button { height: 30px; border: none; border-radius: 8px; background: transparent; color: var(--dsw-alias-label-secondary); cursor: pointer; display: flex; align-items: center; gap: 7px; padding: 0 10px; font-size: 12px; animation: prtsPopUp .16s ease-out; }
  .prtsHoverPop button span { letter-spacing: .02em; }
  .prtsHoverPop button:hover { color: var(--dsw-alias-label-primary); background: var(--dsw-alias-bg-layer-1); }
  @keyframes prtsPopUp { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
  /* drawer sidebar: its own layer — collapse animates like a drawer and
     leaves the chat / composer / background untouched */
  .prtsDrawer { grid-template-columns: 0 minmax(0, 1fr) 0 !important; }
  .prtsDrawer [class*="sidebarCol"] { position: fixed; left: 0; top: 0; bottom: 0; width: 272px; z-index: 40; transform: translateX(0); transition: transform var(--prts-drawer-ms, 380ms) cubic-bezier(.2,.8,.25,1); background: var(--dsw-specific-sidebar-fill, var(--dsw-alias-bg-overlay)); box-shadow: 0 0 40px rgba(0,0,0,.4); }
  .prtsDrawer.prtsDrawerClosed [class*="sidebarCol"] { transform: translateX(calc(-100% + 30px)); }
  .prtsDrawerTab { width: 28px; height: 26px; border: 1px solid var(--dsw-alias-border-l2); border-radius: 8px; background: transparent; color: var(--dsw-alias-label-secondary); cursor: pointer; display: inline-flex; align-items: center; justify-content: center; padding: 0; margin-left: auto; }
  .prtsDrawerTab:hover { color: var(--dsw-alias-label-primary); border-color: var(--prts-accent, var(--dsw-alias-brand-primary)); }
  .prtsDrawerTab svg { transition: transform .3s ease; }
  .prtsDrawer.prtsDrawerClosed .prtsDrawerTab svg { transform: rotate(180deg); }
  /* beat bars beside the PRTS logo (equalizer) */
  .prtsBeat { display: inline-flex; align-items: flex-end; gap: 2px; height: 14px; margin: 0 8px; }
  .prtsBeat i { width: 2.5px; height: 100%; border-radius: 1px; background: var(--dsw-alias-brand-primary); transform-origin: bottom; animation: prtsBeatIdle 1.4s ease-in-out infinite; transform: scaleY(calc(.3 + var(--prts-beat, 0) * .7)); }
  .prtsBeat i:nth-child(2) { animation-delay: .15s; }
  .prtsBeat i:nth-child(3) { animation-delay: .3s; }
  .prtsBeat i:nth-child(4) { animation-delay: .45s; }
  @keyframes prtsBeatIdle { 0%,100% { opacity: .45; } 50% { opacity: 1; } }
  /* day/night toggle beside the logo (custom minimal glyphs) */
  .prtsThemeToggle { width: 26px; height: 26px; border-radius: 8px; border: 1px solid var(--dsw-alias-border-l2); background: transparent; color: var(--dsw-alias-label-primary); cursor: pointer; display: inline-flex; align-items: center; justify-content: center; padding: 0; }
  .prtsThemeToggle:hover { border-color: var(--prts-accent, var(--dsw-alias-brand-primary)); }
  .prtsThemeToggle svg { display: none; }
  .prtsBrandMark { display: inline-block; width: 13px; height: 13px; border: 1.5px solid var(--dsw-alias-brand-primary); transform: rotate(45deg); margin-right: 8px; position: relative; flex: none; }
  .prtsBrandMark::after { content: ''; position: absolute; inset: 3px; background: var(--dsw-alias-brand-primary); }
  /* the built-in whale wordmark is never shown on the main page */
  svg:has([id*="whale"]) { display: none !important; }
  [data-prts-theme='dark'] .prtsThemeToggle svg.sun, [data-prts-theme='light'] .prtsThemeToggle svg.moon { display: block; }
  /* PRTS sidebar widget buttons */
  .prtsWbtn { display: inline-flex; align-items: center; gap: 6px; height: 28px; padding: 0 10px; border: 1px solid var(--dsw-alias-border-l2); border-radius: 8px; background: transparent; color: var(--dsw-alias-label-secondary); font-size: 11px; letter-spacing: 0.08em; cursor: pointer; }
  .prtsWbtn:hover { color: var(--dsw-alias-label-primary); border-color: var(--prts-accent, var(--dsw-alias-brand-primary)); box-shadow: 0 0 10px color-mix(in srgb, var(--prts-accent, var(--dsw-alias-brand-primary)) 35%, transparent); }
  `
  function ensureSkinCss() {
    if (document.getElementById('prts-skin-css')) return
    const s = document.createElement('style')
    s.id = 'prts-skin-css'
    s.textContent = SKIN_CSS
    document.head.appendChild(s)
  }

  /** Particle intro: three acts — "welcome to PRTS" → the PRTS / rule /
   *  DeepSeek Harness banner → the PRTS diamond mark (prts.png). Every act
   *  SCATTERS first, then the particles AGGREGATE into the shape. The loop
   *  keeps playing while dsh loads in the background; once the page is fully
   *  rendered it plays through the current act and enters. */
  function particleIntro(onDone) {
    const box = document.createElement('div')
    box.className = 'prtsIntro'
    const cv = document.createElement('canvas')
    box.appendChild(cv)
    document.body.appendChild(box)
    const ctx = cv.getContext('2d')
    const N = 6500
    const pts = []
    let targets = []
    const W = () => { cv.width = window.innerWidth; cv.height = window.innerHeight }
    W()
    window.addEventListener('resize', W)
    for (let i = 0; i < N; i++) {
      pts.push({ x: Math.random() * cv.width, y: Math.random() * cv.height, s: 0.8 + Math.random() * 1.4 })
    }

    /* ---- act shapes (offscreen renders, sampled into target points) ---- */
    function sampleFrom(c, w, h, step) {
      const d = c.getContext('2d').getImageData(0, 0, w, h).data
      const out = []
      for (let y = 0; y < h; y += step) {
        for (let x = 0; x < w; x += step) {
          if (d[(y * w + x) * 4 + 3] > 128) out.push({ x: x + (cv.width - w) / 2, y: y + (cv.height - h) / 2 })
        }
      }
      return out
    }
    function actWelcome() {
      // Act 1 — "welcome to PRTS": tracked small caps + italic PRTS, one line.
      const w = 1240, h = 330
      const c = document.createElement('canvas'); c.width = w; c.height = h
      const o = c.getContext('2d')
      o.fillStyle = '#fff'; o.textBaseline = 'middle'; o.textAlign = 'center'
      if ('letterSpacing' in o) o.letterSpacing = '8px'
      o.font = '600 72px sans-serif'
      const w1 = o.measureText('welcome to').width
      o.font = 'italic 700 106px sans-serif'
      const w2 = o.measureText('PRTS').width
      const x0 = (w - w1 - w2 - 14) / 2
      o.font = '600 72px sans-serif'
      o.fillText('welcome to', x0 + w1 / 2, h / 2)
      o.font = 'italic 700 106px sans-serif'
      o.fillText('PRTS', x0 + w1 + 14 + w2 / 2, h / 2 + 3)
      return sampleFrom(c, w, h, 2)
    }
    function actBanner() {
      // Act 2 — "DeepSeek Harness" on ONE line (auto-shrunk to fit).
      const w = 1180, h = 260
      const c = document.createElement('canvas'); c.width = w; c.height = h
      const o = c.getContext('2d')
      o.fillStyle = '#fff'; o.textBaseline = 'middle'; o.textAlign = 'center'
      let size = 118
      while (size > 40) {
        o.font = '700 ' + size + 'px sans-serif'
        if (o.measureText('DeepSeek Harness').width <= w - 40) break
        size -= 6
      }
      o.fillText('DeepSeek Harness', w / 2, h / 2)
      return sampleFrom(c, w, h, 2)
    }
    function actMark() {
      // Act 3 — the PRTS mark (prts.png): diamond outline, italic P/R/T/S in
      // the four corners, "dsh" wordmark and its accent rule in the centre.
      const w = 480, h = 480
      const c = document.createElement('canvas'); c.width = w; c.height = h
      const o = c.getContext('2d')
      o.fillStyle = '#fff'; o.strokeStyle = '#fff'
      const cx = w / 2, cy = h / 2, half = 188
      o.lineWidth = 8; o.lineJoin = 'round'
      o.beginPath()
      o.moveTo(cx, cy - half); o.lineTo(cx + half, cy); o.lineTo(cx, cy + half); o.lineTo(cx - half, cy)
      o.closePath(); o.stroke()
      o.textAlign = 'center'; o.textBaseline = 'middle'
      o.font = 'italic 700 78px sans-serif'
      o.fillText('P', cx - 70, cy - 70)
      o.fillText('R', cx + 70, cy - 70)
      o.fillText('T', cx - 70, cy + 70)
      o.fillText('S', cx + 70, cy + 70)
      o.font = 'italic 700 40px sans-serif'; o.textBaseline = 'alphabetic'
      o.fillText('dsh', cx, cy + 28)
      o.fillRect(cx - 42, cy + 42, 84, 4)
      return sampleFrom(c, w, h, 2)
    }
    const SHAPES = [actWelcome, actBanner, actMark]

    /* ---- scatter -> aggregate -> hold rhythm ---- */
    let act = 0
    let phase = 'scatter'
    let actT0 = 0
    let shapePts = []
    let ready = false
    let done = false
    let played = 0   // completed acts — the full 3-act cycle plays at least once
    const scatterTargets = () => {
      // random RADIAL scatter (no rectangular boundary): every particle
      // flies out in a random direction/distance from the centre
      const out = []
      const cx = cv.width / 2, cy = cv.height / 2
      const maxR = Math.min(cv.width, cv.height) * 0.42
      for (let i = 0; i < N; i++) {
        const a = Math.random() * Math.PI * 2
        const r = maxR * Math.sqrt(Math.random())
        out.push({ x: cx + Math.cos(a) * r, y: cy + Math.sin(a) * r })
      }
      return out
    }
    const shapeTargets = () => {
      const out = []
      for (let i = 0; i < N; i++) {
        const p = shapePts[i % shapePts.length]
        out.push(p ? { x: p.x + (Math.random() - 0.5) * 2, y: p.y + (Math.random() - 0.5) * 2 } : { x: Math.random() * cv.width, y: Math.random() * cv.height })
      }
      return out
    }
    const assignAct = (reset) => {
      if (reset) shapePts = SHAPES[act]()
      targets = scatterTargets()
      phase = 'scatter'
      actT0 = performance.now()
    }
    const nextAct = () => {
      played++
      act = (act + 1) % SHAPES.length
      shapePts = SHAPES[act]()
      assignAct(false)
    }
    assignAct(true)

    let raf = 0
    let lastNow = 0
    const frame = (now) => {
      ctx.clearRect(0, 0, cv.width, cv.height)
      const t = (now - actT0) / 1000
      if (phase === 'scatter' && t > 0.9) { targets = shapeTargets(); phase = 'hold' }
      if (phase === 'hold' && t > 4.4) { if (played >= 3) finish(); else nextAct() }
      // Time-based ease (not per-frame): the app boot starves rAF, so a
      // fixed per-frame factor would crawl at low FPS and never aggregate.
      const dt = lastNow ? Math.max(0.001, (now - lastNow) / 1000) : 0.016
      lastNow = now
      // slower, gentler motion (time-based so a busy boot never freezes it)
      const k = 1 - Math.exp(-dt * 2.8)
      ctx.fillStyle = '#FAFAFA'
      for (let i = 0; i < N; i++) {
        const p = pts[i]
        const tg = targets[i]
        if (tg) { p.x += (tg.x - p.x) * k; p.y += (tg.y - p.y) * k }
        ctx.globalAlpha = 0.7
        ctx.fillRect(p.x, p.y, p.s, p.s)
      }
      ctx.globalAlpha = 1
      raf = requestAnimationFrame(frame)
    }
    raf = requestAnimationFrame(frame)

    // status line under the particles: loading until the page is fully ready
    const status = document.createElement('div')
    status.style.cssText = 'position:fixed;bottom:22px;left:0;right:0;text-align:center;color:#9C9CA1;font-size:12px;letter-spacing:0.18em;z-index:3;pointer-events:none;'
    status.textContent = '后台加载中…'
    box.appendChild(status)

    function finish() {
      if (done) return
      done = true
      cancelAnimationFrame(raf)
      box.classList.add('done')
      setTimeout(() => { box.remove(); if (onDone) onDone() }, 700)
    }
    // "fully loaded" = document complete + the first real UI is on screen.
    // Hard 20s cap: the intro must NEVER hang the app — after the cap it
    // plays through the current act and enters regardless.
    const waitReady = async () => {
      const t0 = Date.now()
      while (Date.now() - t0 < 20000) {
        const complete = document.readyState === 'complete'
        const uiUp = !!(document.querySelector('textarea') || document.querySelector('button') || document.querySelector('[class*="sidebar"]'))
        if (complete && uiUp) break
        await new Promise((r) => setTimeout(r, 300))
      }
      ready = true
      status.textContent = 'READY · 进入中…'
    }
    waitReady()
    // Click anywhere enters immediately — the three acts still play through
    // on their own (scatter → aggregate each) and then enter.
    box.addEventListener('click', () => finish())
    return finish
  }

  /** Remove every DeepSeek element → PRTS (brand text, logo, title, favicon). */
  function swapBrand() {
    // Targeted, hand-applied UI changes — NO global text replacement. Only
    // the MAIN page changes: the top-left brand, the top-right logo and the
    // 预览版 badge. Settings / 余额 / 模型 and every other page keep the
    // original DeepSeek branding.
    document.title = 'PRTS'
    const brandMark = '<span class="rhombus" style="position:relative;display:inline-block"></span>'
    const markSettingsRoots = () => {
      const b = [...document.querySelectorAll('button')].find((x) => (x.textContent || '').indexOf('打开配置文件') >= 0)
      if (!b) return
      let el = b
      while (el && el !== document.body) { el.setAttribute('data-prts-settings', '1'); el = el.parentElement }
    }
    const inSettings = (node) => { let el = node; while (el) { if (el.getAttribute && el.getAttribute('data-prts-settings') === '1') return true; el = el.parentElement } return false }

    const walk = () => {
      markSettingsRoots()
      /* --- top-left brand: diamond + italic PRTS (beat bars + day/night
             toggle ride along; the packaged prts.png is NOT used here) --- */
      const logoRow = document.querySelector('[class*="logoRow"]')
      if (logoRow && !logoRow.dataset.prtsLogo) {
        logoRow.dataset.prtsLogo = '1'
        // drop the original whale mark + any image
        for (const el of [...logoRow.querySelectorAll('svg, img')]) { try { el.remove() } catch (e) { /* noop */ } }
        // diamond mark at the front
        const mark = document.createElement('span')
        mark.className = 'prtsBrandMark'
        logoRow.insertBefore(mark, logoRow.firstChild)
        // the brand name becomes italic PRTS (wrapped text node or leaf el)
        const nameEl = [...logoRow.querySelectorAll('span, div, p, h1, h2, h3, a')].find((el) => (el.textContent || '').trim().length > 0 && el.children.length === 0)
        if (nameEl) {
          nameEl.textContent = 'PRTS'
          nameEl.style.fontStyle = 'italic'
          nameEl.style.letterSpacing = '0.22em'
          nameEl.style.fontWeight = '600'
        } else {
          const tns = [...logoRow.childNodes].filter((n) => n.nodeType === 3 && (n.textContent || '').trim())
          if (tns.length) {
            const sp = document.createElement('span')
            sp.textContent = 'PRTS'
            sp.style.fontStyle = 'italic'
            sp.style.letterSpacing = '0.22em'
            sp.style.fontWeight = '600'
            tns[0].replaceWith(sp)
            for (let i = 1; i < tns.length; i++) { try { tns[i].remove() } catch (e) { /* noop */ } }
          } else {
            const sp2 = document.createElement('span')
            sp2.textContent = 'PRTS'
            sp2.style.fontStyle = 'italic'
            sp2.style.letterSpacing = '0.22em'
            sp2.style.fontWeight = '600'
            logoRow.insertBefore(sp2, mark.nextSibling)
          }
        }
        // beat bars: vibrate together with the background diamond/square
        const bars = document.createElement('span')
        bars.className = 'prtsBeat'
        bars.innerHTML = '<i></i><i></i><i></i><i></i>'
        bars.title = '声音律动'
        logoRow.appendChild(bars)
        // day/night toggle (custom minimal glyphs — no emoji)
        const tt = document.createElement('button')
        tt.type = 'button'
        tt.className = 'prtsThemeToggle'
        tt.title = '切换白天 / 黑夜'
        tt.innerHTML = '<svg class="sun" width="13" height="13" viewBox="0 0 13 13" fill="none">' +
          '<circle cx="6.5" cy="6.5" r="2.4" stroke="currentColor" stroke-width="1.2"/>' +
          '<path d="M6.5 1v1.6M6.5 10.4V12M1 6.5h1.6M10.4 6.5H12M2.6 2.6l1.1 1.1M9.3 9.3l1.1 1.1M10.4 2.6 9.3 3.7M3.7 9.3l-1.1 1.1" stroke="currentColor" stroke-width="1.1" stroke-linecap="round"/></svg>' +
          '<svg class="moon" width="12" height="12" viewBox="0 0 12 12" fill="none">' +
          '<path d="M10.4 7.2A4.6 4.6 0 0 1 4.8 1.6 4.7 4.7 0 1 0 10.4 7.2Z" stroke="currentColor" stroke-width="1.2" stroke-linejoin="round"/></svg>'
        tt.addEventListener('click', (e) => {
          e.stopPropagation()
          try {
            if (theme && typeof theme.setTheme === 'function') {
              const snap = theme.getTheme ? theme.getTheme() : null
              const active = (snap && snap.active && snap.active.id) || (snap && snap.preference) || (snap && snap.id) || 'dark'
              theme.setTheme(active === 'dark' ? 'light' : 'dark')
            }
          } catch (err) { /* noop */ }
        })
        logoRow.appendChild(tt)
      }
      /* --- top-right DeepSeek logo → the diamond + italic PRTS mark
             (main page only; settings keep DeepSeek) --- */
      const topRightCands = [...document.querySelectorAll('img[src*="logo"], img[src*="brand"], svg, [class*="logo"], [class*="brand"], [class*="Brand"]')]
        .filter((el) => {
          if (el.closest && (el.closest('[data-prts-logo]') || el.closest('[data-prts-settings]') || el.closest('.prtsTitlebar') || el.closest('[class*="logoRow"]') || el.closest('button'))) return false
          if (el.querySelector && el.querySelector('[class*="logoRow"]')) return false
          const r = el.getBoundingClientRect()
          return r.width > 0 && r.width <= 240 && r.top < 90 && r.left > window.innerWidth * 0.55
        })
      // Replace ONLY real img/svg marks — never a container div (replacing a
      // container would wipe the buttons living inside it).
      const target = topRightCands.find((el) => /^(img|svg)$/i.test(el.tagName))
      if (target && !target.dataset.prtsSwapped && target.parentNode) {
        target.dataset.prtsSwapped = '1'
        const brand = document.createElement('span')
        brand.className = 'prtsBrand'
        brand.innerHTML = brandMark + '<span style="font-style:italic;letter-spacing:.22em;font-weight:600">PRTS</span>'
        brand.style.display = 'inline-flex'
        brand.style.alignItems = 'center'
        brand.style.gap = '8px'
        target.parentNode.replaceChild(brand, target)
      }
      /* --- stray DeepSeek logos on the MAIN page are removed (never inside
             the settings panel, never the two marks above) --- */
      for (const el of [...document.querySelectorAll('.prtsLogoMark, img[src*="logo"], img[src*="brand"], img[src*="whale"], svg[class*="logo"], svg[class*="whale"], [class*="whale"]')]) {
        if (el.closest && (el.closest('[data-prts-logo]') || el.closest('[data-prts-settings]') || el.closest('.prtsBrand') || el.closest('button'))) continue
        try { el.remove() } catch (e) { /* noop */ }
      }
      // the dsh-web built-in wordmark embeds the whale as an SVG clip path —
      // its class is hashed, so match the content instead
      for (const svg of [...document.querySelectorAll('svg')]) {
        try {
          if (String(svg.innerHTML).indexOf('whale') < 0) continue
          if (svg.closest && (svg.closest('[data-prts-settings]') || svg.closest('[data-prts-logo]'))) continue
          svg.remove()
        } catch (e) { /* noop */ }
      }
    }
    walk()
    setTimeout(walk, 1500)
    setTimeout(walk, 4000)
    // favicon → PRTS mark (served by the host plugin)
    if (!document.getElementById('prts-favicon')) {
      fetch(origin() + '/prts/api/logo').then((r) => r.json()).then((d) => {
        if (!d || !d.b64) return
        const link = document.createElement('link')
        link.id = 'prts-favicon'
        link.rel = 'icon'
        link.type = 'image/png'
        link.href = 'data:image/png;base64,' + d.b64
        document.head.appendChild(link)
      }).catch(() => {})
    }
  }

  /** Hero (blank conversation): PRTS italic + a diamond with a solid square
   *  inside, centered, and the localized welcome tag below — no glow. Only
   *  the dsh-web brand/tagline block is replaced; the workspace chips and
   *  the COMPOSER below it are never touched. */
  function prtsLang() {
    const lang = String((document.documentElement && document.documentElement.lang) || (typeof navigator !== 'undefined' && navigator.language) || '')
    return /^zh/i.test(lang) ? 'zh' : 'en'
  }
  function swapHero() {
    const tag = prtsLang() === 'zh' ? '欢迎回归，博士' : 'Welcome back, Doctor'
    const walk = () => {
      const cands = [...document.querySelectorAll('div,span,h1,h2,p')].filter((d) => {
        // never touch the composer / inputs / buttons / the sidebar / our hero
        if (d.querySelector('textarea, input, button, .prtsHero')) return false
        if (d.closest && d.closest('[class*="sidebar"]')) return false
        const t = (d.textContent || '').trim()
        if (!t || t.length > 60) return false
        return /^(探索未至之境|探索|explore[^.]*|deepseek harness[\s\S]{0,20}探索)/i.test(t) ||
          (/deepseek/i.test(t) && /探索|explore/i.test(t))
      })
      const target = cands[cands.length - 1]
      if (!target || target.querySelector('.prtsHero') || target.closest('.prtsHero')) return
      target.innerHTML = ''
      const hero = document.createElement('div')
      hero.className = 'prtsHero'
      const row = document.createElement('div')
      row.className = 'row'
      const mark = document.createElement('span')
      mark.className = 'prtsHeroMark'
      mark.innerHTML = '<span class="sq"></span>'
      const word = document.createElement('span')
      word.className = 'word'
      word.textContent = 'PRTS'
      row.appendChild(mark)
      row.appendChild(word)
      const tagline = document.createElement('span')
      tagline.className = 'tag'
      tagline.textContent = tag
      hero.appendChild(row)
      hero.appendChild(tagline)
      target.appendChild(hero)
    }
    walk()
    setTimeout(walk, 1500)
    setTimeout(walk, 3500)
    setTimeout(walk, 6000)
  }

  /** Composer: always pinned to the bottom (even before any conversation),
   *  slightly enlarged so the workspace picker never overflows into it, plus
   *  the notched-arrow expand handle (click toggles, drag up expands). */
  function composerExpand() {
    const walk = () => {
      const ta = document.querySelector('textarea')
      if (!ta) return
      // While no conversation exists, pin the composer to the bottom of the
      // conversation column (fixed, so no ancestor clipping) and enlarge it
      // so the workspace picker row never overflows into it. Once a chat
      // starts, dsh-web's own layout takes over and the pin is removed.
      const empty = !!document.querySelector('.prtsHero')
      // Chat mode: centre dsh-web's own bottom composer stack as well.
      if (!empty) {
        const stack = ta.closest('[class*="composerStack"], [class*="composer"]')
        if (stack && stack !== document.body) {
          const w = Math.min(760, window.innerWidth - 48)
          stack.style.setProperty('left', Math.round((window.innerWidth - w) / 2) + 'px', 'important')
          stack.style.setProperty('right', 'auto', 'important')
          stack.style.setProperty('width', Math.round(w) + 'px', 'important')
        }
      }
      // In the empty state dsh-web centres the whole hero block (and with it
      // the composer) vertically. Un-centre it: the hero root becomes a
      // bottom-anchored column, so the workspace-picker chips AND the whole
      // composer card sink to the bottom of the conversation column. The
      // PRTS hero itself is fixed-centred and stays in the middle.
      const heroRoot = ta.closest('[class*="hero"]')
      const card = ta.closest('[class*="card"]') || heroRoot
      const center = document.querySelector('[class*="centerCol"]')
      // The empty-state composer SEAT (the block holding the chips + the
      // whole composer) is pinned to the bottom of the conversation column.
      // The PRTS hero itself is fixed-centred and unaffected.
      const seat = ta.closest('[class*="Seat"]') || ta.closest('[class*="seat"]') || heroRoot
      if (empty && seat && center) {
        // centred at the very bottom of the window (buttons ride along)
        const r = center.getBoundingClientRect()
        const w = Math.min(760, r.width - 24)
        seat.dataset.prtsPinned = '1'
        seat.style.setProperty('position', 'fixed', 'important')
        // no transform here — a transform would become the containing block
        // for position:fixed children (the PRTS hero) and break centring
        seat.style.setProperty('left', Math.round((window.innerWidth - w) / 2) + 'px', 'important')
        seat.style.setProperty('transform', 'none', 'important')
        seat.style.setProperty('width', Math.round(w) + 'px', 'important')
        seat.style.setProperty('bottom', '0', 'important')
        seat.style.setProperty('z-index', '10', 'important')
        seat.style.setProperty('padding', '0 0 10px', 'important')
        if (card) card.classList.add('prtsGlassCard')
      } else if (!empty) {
        for (const t of [...document.querySelectorAll('[data-prts-pinned]')]) {
          delete t.dataset.prtsPinned
          for (const k of ['position', 'left', 'right', 'transform', 'width', 'bottom', 'z-index', 'padding']) t.style.removeProperty(k)
        }
      }
      if (document.querySelector('.prtsExpand')) return
      let host = ta.parentElement
      for (let i = 0; i < 6 && host; i++) {
        if (getComputedStyle(host).position === 'relative' || getComputedStyle(host).position === 'absolute') break
        host = host.parentElement
      }
      const wrap = ta.closest('form') || ta.parentElement.parentElement
      if (!wrap) return
    }
    walk()
    setTimeout(walk, 2000)
    setTimeout(walk, 5000)
  }

  /** Background diamond + square (vibrates while voice is on / beat mode). */
  function backgroundMarks() {
    if (document.getElementById('prtsBgMarks')) return document.getElementById('prtsBgMarks')
    const marks = document.createElement('div')
    marks.id = 'prtsBgMarks'
    marks.className = 'prtsBgMarks'
    marks.innerHTML = '<span class="d"></span><span class="s"></span>'
    document.body.appendChild(marks)
    return marks
  }

  /** System-sound beat: captures OS audio (display media) and drives the
   *  background diamond/square with an analyser. */
  let beatCtx = null, beatStream = null, beatRaf = 0
  function stopBeat() {
    cancelAnimationFrame(beatRaf)
    beatRaf = 0
    if (beatCtx) { try { beatCtx.close() } catch (e) { /* noop */ } beatCtx = null }
    if (beatStream) { try { beatStream.getTracks().forEach((t) => t.stop()) } catch (e) { /* noop */ } beatStream = null }
    const marks = document.getElementById('prtsBgMarks')
    if (marks) { marks.classList.remove('beat') }
    document.documentElement.style.setProperty('--prts-beat', '0')
  }
  async function startBeat() {
    const marks = backgroundMarks()
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) throw new Error('unsupported')
      beatStream = await navigator.mediaDevices.getDisplayMedia({ video: false, audio: true })
      const AC = window.AudioContext || window.webkitAudioContext
      if (!AC) throw new Error('no AudioContext')
      beatCtx = new AC()
      const src = beatCtx.createMediaStreamSource(beatStream)
      const an = beatCtx.createAnalyser()
      an.fftSize = 512
      src.connect(an)
      const data = new Uint8Array(an.frequencyBinCount)
      marks.classList.add('beat')
      const loop = () => {
        an.getByteFrequencyData(data)
        let sum = 0
        for (let i = 0; i < data.length; i++) sum += data[i]
        const avg = sum / data.length / 255
        document.documentElement.style.setProperty('--prts-beat', Math.min(1, avg * 2.4).toFixed(3))
        beatRaf = requestAnimationFrame(loop)
      }
      loop()
      return true
    } catch (e) {
      stopBeat()
      return false
    }
  }

  /** Voice button: inserted beside the composer controls; vibrates the marks. */
  function voiceButton() {
    const walk = () => {
      const ta = document.querySelector('textarea')
      if (!ta || document.querySelector('.prtsVoice')) return
      const row = ta.parentElement
      if (!row) return
      const btn = document.createElement('button')
      btn.type = 'button'
      btn.className = 'prtsWbtn prtsVoice'
      btn.title = '语音输入'
      btn.innerHTML = '<span>🎙</span> VOICE'
      let on = false
      btn.addEventListener('click', () => {
        on = !on
        const marks = backgroundMarks()
        marks.classList.toggle('vib', on)
        btn.style.color = on ? 'var(--prts-accent, var(--dsw-alias-brand-primary))' : ''
      })
      row.appendChild(btn)
    }
    walk()
    setTimeout(walk, 2500)
  }

  /** Keep the background diamond/square and the hero centred on the
   *  CONVERSATION column (not the raw viewport): the sidebar shifts the
   *  visual centre, so both track the column's centre instead. */
  function recenterMarks() {
    const center = document.querySelector('[class*="centerCol"]')
    const marks = document.getElementById('prtsBgMarks')
    const hero = document.querySelector('.prtsHero')
    const cx = center ? center.getBoundingClientRect() : null
    const x = cx ? Math.round(cx.left + cx.width / 2) : Math.round(window.innerWidth / 2)
    const y = Math.round(window.innerHeight / 2)
    if (marks) { marks.style.left = x + 'px'; marks.style.top = y + 'px' }
    if (hero) { hero.style.left = x + 'px'; hero.style.top = y + 'px' }
  }

  /** The sidebar is a DRAWER on its own layer: toggling slides it in/out
   *  with a spring-like motion and changes NOTHING else (chat, composer and
   *  background stay put). One tab button — next to the day/night toggle in
   *  the brand row — moves with the drawer and peeks at the edge when
   *  closed. Collapsed IS the default state. */
  function sidebarRescue() {
    const col = document.querySelector('[class*="sidebarCol"]')
    const frame = document.querySelector('#root [class*="frame"], #root [class$="frame"]') || col
    if (!col) return
    if (document.documentElement.dataset.prtsDrawerOff === '1') {
      frame.classList.remove('prtsDrawer', 'prtsDrawerClosed')
      return
    }
    if (!frame.classList.contains('prtsDrawer')) {
      frame.classList.add('prtsDrawer', 'prtsDrawerClosed')
      // the drawer overlays the page — the content column keeps full width
    }
    let btn = document.getElementById('prtsSbToggle')
    const logoRow = document.querySelector('[class*="logoRow"]')
    if (!btn && logoRow) {
      btn = document.createElement('button')
      btn.id = 'prtsSbToggle'
      btn.type = 'button'
      btn.className = 'prtsDrawerTab'
      btn.title = '侧边栏'
      btn.innerHTML = '<svg width="12" height="12" viewBox="0 0 13 13" fill="none">' +
        '<path d="M4.6 2.6 8.9 6.5 4.6 10.4" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/>' +
        '<path d="M11 2v9" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>'
      btn.addEventListener('click', (e) => {
        e.stopPropagation()
        const open = !frame.classList.contains('prtsDrawerClosed')
        frame.classList.toggle('prtsDrawerClosed', open)
        window.PRTS_MOTION && window.PRTS_MOTION.drawer && window.PRTS_MOTION.drawer(frame, !open)
      })
      logoRow.appendChild(btn)
      logoRow.style.position = 'relative'
    }
    // hide dsh-web's own toggle — exactly one drawer tab (never ours)
    for (const b of [...document.querySelectorAll('button')]) {
      if (b === btn || b.classList.contains('prtsThemeToggle')) continue
      if (/toggle/i.test(String(b.className || ''))) { b.dataset.prtsOwn = '1'; b.style.display = 'none' }
    }
  }

  /** The 动效 (motion) plugin: one reusable motion service every surface
   *  (sidebar drawers, bottom/top bars, future plugins, even GitHub
   *  plugins' sidebars) can call for drawer / spring / vibration effects. */
  window.PRTS_MOTION = {
    /** Drawer: slide an element in/out like a drawer (translateX). */
    drawer(el, open, ms) {
      if (!el) return
      const t = ms || 380
      el.style.transition = 'transform ' + (t / 1000) + 's cubic-bezier(.2,.8,.25,1)'
      el.style.transform = open ? 'translateX(0)' : 'translateX(calc(-100% + 30px))'
    },
    /** Spring: pop an element with a springy scale pulse. */
    spring(el, opts) {
      if (!el) return
      const o = opts || {}
      el.style.transition = 'transform .18s cubic-bezier(.34,1.56,.64,1)'
      el.style.transform = 'scale(' + (o.to || 1.06) + ')'
      setTimeout(() => { el.style.transform = 'scale(1)' }, 180)
    },
    /** Vibrate: shake/vibrate an element for a moment. */
    vibrate(el, opts) {
      if (!el) return
      const o = opts || {}
      const key = 'prtsVib' + Date.now()
      const style = document.getElementById('prts-motion-style') || (() => { const st = document.createElement('style'); st.id = 'prts-motion-style'; document.head.appendChild(st); return st })()
      style.textContent += '@keyframes ' + key + '{0%,100%{transform:translate(0,0)}25%{transform:translate(' + (o.dx || 2) + 'px,' + (o.dy || 0) + 'px)}75%{transform:translate(-' + (o.dx || 2) + 'px,0)}}'
      el.style.animation = key + ' ' + (o.ms || 120) + 'ms linear ' + (o.times || 4)
      setTimeout(() => { el.style.animation = '' }, (o.ms || 120) * (o.times || 4) + 50)
    },
    /** Wrap ANY sidebar-like element (even other plugins') in the drawer. */
    animateSidebar(el, opts) {
      if (!el) return
      const o = opts || {}
      const w = el.getBoundingClientRect().width || 272
      el.style.position = 'fixed'
      el.style.left = '0'
      el.style.top = o.top || '0'
      el.style.bottom = o.bottom || '0'
      el.style.zIndex = o.zIndex || 40
      el.style.width = w + 'px'
      el.style.transition = 'transform .38s cubic-bezier(.2,.8,.25,1)'
      el.style.transform = 'translateX(calc(-100% + 30px))'
      el.dataset.prtsDrawer = '1'
      el.dataset.prtsDrawerOpen = ''
      return {
        toggle() {
          const open = el.dataset.prtsDrawerOpen !== '1'
          el.dataset.prtsDrawerOpen = open ? '1' : ''
          el.style.transform = open ? 'translateX(0)' : 'translateX(calc(-100% + 30px))'
          return open
        },
      }
    },
  }

  /** Custom window bar: full-black strip, three circles (− □ ×), revealed
   *  when the cursor nears the top edge. Window controls ride the preload
   *  bridge; in a plain browser tab the bar simply hides itself. */
  function titlebar() {
    if (document.getElementById('prtsTitlebar')) return
    const bar = document.createElement('div')
    bar.id = 'prtsTitlebar'
    bar.className = 'prtsTitlebar'
    const mk = (cls, glyph, act) => {
      const b = document.createElement('button')
      b.type = 'button'
      b.className = 'winBtn ' + cls
      b.innerHTML = glyph
      b.title = act.title
      b.addEventListener('click', (e) => { e.stopPropagation(); act.fn() })
      return b
    }
    const bridge = window.prts && window.prts.bridge
    const win = bridge && bridge.win
    if (win && typeof win.minimize === 'function') {
      bar.appendChild(mk('min', '<span style="transform:translateY(-3px)">−</span>', { title: '隐藏', fn: () => win.minimize() }))
      bar.appendChild(mk('max', '<span style="font-size:9px">◻</span>', { title: '放大', fn: () => win.toggleMaximize() }))
      bar.appendChild(mk('close', '<span>×</span>', { title: '退出', fn: () => win.close() }))
    } else {
      bar.appendChild(mk('close', '<span>×</span>', { title: '退出', fn: () => { try { window.close() } catch (e) { /* noop */ } } }))
    }
    document.body.appendChild(bar)
    // Shift the dsh-web frame below the bar (browser-like chrome): nothing
    // under the circles is covered — the logo row, header buttons and the
    // composer all keep their own space.
    const shiftFrame = () => {
      const frame = document.querySelector('#root [class$="frame"], #root [class*="frame"]')
      if (!frame) return
      const barH = 34
      frame.style.marginTop = barH + 'px'
      frame.style.height = 'calc(100% - ' + barH + 'px)'
    }
    shiftFrame()
    setTimeout(shiftFrame, 1200)
    setTimeout(shiftFrame, 3500)
  }

  /** Remove the "预览版" preview badge and any stray brand marks above the
   *  composer (the empty-state extras). */
  function cleanHeaderExtras() {
    for (const el of [...document.querySelectorAll('[class*="previewBadge"]')]) {
      try { el.remove() } catch (e) { /* noop */ }
    }
  }

  /** Only ONE API-key prompt may exist: PRTS owns it, so dsh-web's own
   *  onboarding dialog is dismissed wherever it appears. */
  function dismissNativeOnboarding() {
    // hide first (no flash while the particle intro plays), then dismiss
    const btns = [...document.querySelectorAll('button')]
    for (const b of btns) {
      const t = (b.textContent || '').trim()
      if (!/^(稍后配置|稍后|skip|later)$/i.test(t)) continue
      if (b.closest && b.closest('.prtsOnboard')) continue   // ours — keep it
      let overlay = b
      while (overlay && overlay !== document.body) {
        const cs = getComputedStyle(overlay)
        if ((cs.position === 'fixed' || cs.position === 'absolute') && overlay.getBoundingClientRect().width > window.innerWidth * 0.5) break
        overlay = overlay.parentElement
      }
      if (overlay && overlay !== document.body) { overlay.style.display = 'none'; overlay.dataset.prtsHidden = '1' }
      try { b.click() } catch (e) { /* noop */ }
      return
    }
  }

  /* ---------- mount the skin ---------- */
  // Only ONE particle intro exists — the Electron splash (the docs/ engine,
  // 1:1). The skin settles right away; the API-key prompt appears shortly
  // after entering.
  let skinEntered = true
  const skinWalk = () => {
    swapBrand(); swapHero(); composerExpand(); sidebarRescue(); cleanHeaderExtras(); recenterMarks(); dismissNativeOnboarding()
  }
  ensureSkinCss()
  backgroundMarks()
  titlebar()
  swapBrand()
  recenterMarks()
  dismissNativeOnboarding()
  skinWalk()
  setTimeout(showOnboarding, 1200)
  window.addEventListener('resize', () => { recenterMarks(); composerExpand() })
  ctx.effect(() => {
    const int = ctx.get('timer') ? ctx.get('timer').interval(skinWalk, 6000) : null
    return () => { if (int) int() }
  })

  ctx.effect(() => () => { if (styleEl) { styleEl.remove(); styleEl = null } })
}

export default { apply }
