PRTS on Android (Termux)
------------------------
1. Install Termux (F-Droid build recommended).
2. pkg update && pkg install -y nodejs git curl termux-api
3. Copy the dsh-prts-ui folder to ~/ and run:
     cd ~/dsh-prts-ui && sh install-android.sh
4. Start with `prts`, then open http://127.0.0.1:3080 in your browser.

Tip: the PRTS website is a PWA — open it in Chrome and choose
"Add to Home screen" for an app-like launcher.
