/**
 * PRTS preload: exposes the io bridge (fs + http with chunk streaming) and
 * the abort channel to the isolated renderer via contextBridge.
 */
const { contextBridge, ipcRenderer } = require('electron')

const pending = new Map()

const dshUrl = process.argv.find((a) => a.startsWith('--dsh-url='))?.slice('--dsh-url='.length) || 'http://127.0.0.1:3085'

let prtsVersion = '0.0.0'
try { prtsVersion = require('../package.json').version || '0.0.0' } catch (e) { /* ignore */ }

contextBridge.exposeInMainWorld('prts', {
  env: {
    platform: process.platform,
    home: process.env.HOME || process.env.USERPROFILE || '',
    dshHome: process.env.DSH_HOME || (process.env.HOME || process.env.USERPROFILE || '') + '/.dsh',
    xdgConfigHome: process.env.XDG_CONFIG_HOME || '',
    xdgDesktopDir: process.env.XDG_DESKTOP_DIR || '',
    appData: process.env.APPDATA || '',
    dshUrl,
    prtsVersion,
  },
  bridge: {
    readFile: (p) => ipcRenderer.invoke('prts:readFile', p),
    writeFile: (p, d) => ipcRenderer.invoke('prts:writeFile', p, d),
    appendFile: (p, d) => ipcRenderer.invoke('prts:appendFile', p, d),
    deleteFile: (p) => ipcRenderer.invoke('prts:deleteFile', p),
    exists: (p) => ipcRenderer.invoke('prts:exists', p),
    mkdir: (p) => ipcRenderer.invoke('prts:mkdir', p),
    listDir: (p) => ipcRenderer.invoke('prts:listDir', p),
    systemInfo: () => ipcRenderer.invoke('prts:systemInfo'),
    pickDirectory: (title) => ipcRenderer.invoke('prts:pickDirectory', title),
    pluginsList: () => ipcRenderer.invoke('prts:listPlugins'),
    pluginAdd: (pkg) => ipcRenderer.invoke('prts:pluginAdd', pkg),
    pluginClone: (repo) => ipcRenderer.invoke('prts:pluginClone', repo),
    listProfiles: () => ipcRenderer.invoke('prts:listProfiles'),
    runCli: (profile, args) => ipcRenderer.invoke('prts:runCli', profile, args),
    shell: (cmd, args) => ipcRenderer.invoke('prts:shell', cmd, args),
    openExternal: (url) => ipcRenderer.invoke('prts:openExternal', url),
    listSkills: () => ipcRenderer.invoke('prts:listSkills'),
    readSkill: (name) => ipcRenderer.invoke('prts:readSkill', name),
    writeSkill: (name, content) => ipcRenderer.invoke('prts:writeSkill', name, content),
    deleteSkill: (name) => ipcRenderer.invoke('prts:deleteSkill', name),
    skillInstall: (repo, subdir) => ipcRenderer.invoke('prts:skillInstall', repo, subdir),
    openPath: (p) => ipcRenderer.invoke('prts:openPath', p),
    readFileB64: (p) => ipcRenderer.invoke('prts:readFileB64', p),
    writeFileB64: (p, b64) => ipcRenderer.invoke('prts:writeFileB64', p, b64),
    loginDeepseek: () => ipcRenderer.invoke('prts:loginDeepseek'),
    loginGithub: () => ipcRenderer.invoke('prts:loginGithub'),
    update: () => ipcRenderer.invoke('prts:update'),
    download: (url) => ipcRenderer.invoke('prts:download', url),
    sttFile: (rel) => ipcRenderer.invoke('prts:sttFile', rel),
    dsh: {
      request: (method, payload) => ipcRenderer.invoke('prts:dshRequest', method, payload),
      respond: (rpcId, result) => ipcRenderer.invoke('prts:dshRespond', rpcId, result),
      onFrame: (cb) => ipcRenderer.on('prts:dshFrame', (_e, data) => cb(data)),
    },
    http(req) {
      const token = req.token || ('h' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6))
      pending.set(token, req)
      ipcRenderer.invoke('prts:http', { method: req.method, url: req.url, headers: req.headers, body: req.body, token })
        .then((res) => { pending.delete(token); if (req.onEnd) req.onEnd(res) })
        .catch((err) => { pending.delete(token); if (req.onEnd) req.onEnd({ status: 0, message: String(err && err.message || err) }) })
      return Promise.resolve({ status: 0 })
    },
    abort: (token) => ipcRenderer.invoke('prts:abort', token),
  },
})

ipcRenderer.on('prts:chunk', (_e, token, text) => {
  const r = pending.get(token)
  if (r && r.onChunk) r.onChunk(text)
})
ipcRenderer.on('prts:end', (_e, token, result) => {
  const r = pending.get(token)
  if (!r) return
  pending.delete(token)
  if (r.onEnd) r.onEnd(result)
})
